public class Adventure {
    public int moodChecker = 0;
    public static int lifeChecker = 0;

    public Adventure() {
        this.moodChecker = 0;
    }    

    public String moodMeter() {
        if (this.moodChecker >= 0 && this.moodChecker <= 2) {
            return "Depressed";
        } else if (this.moodChecker >= 3 && this.moodChecker <= 5) {
            return "Ok";
        } else if (this.moodChecker >= 6 && this.moodChecker <= 10) {
            return "Happy";
        }
        return "Current mood is unknown...";
    }



    public static void bankrupcy() {
        lifeChecker = 0;
    }
    
}