import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class AdventureTest {

    Adventure adventure;

    @Before
    public void initialization() {
        adventure = new Adventure();
    }

    @Test
    public void testMoodMeterDepressed() {
        // Test when moodChecker is in the "Depressed" range (0-2)
        adventure.moodChecker = 0;
        assertEquals("Depressed", adventure.moodMeter());

        adventure.moodChecker = 2;
        assertEquals("Depressed", adventure.moodMeter());
    }

    @Test
    public void testMoodMeterOk() {
        // Test when moodChecker is in the "Ok" range (3-5)
        adventure.moodChecker = 3;
        assertEquals("Ok", adventure.moodMeter());

        adventure.moodChecker = 5;
        assertEquals("Ok", adventure.moodMeter());
    }

    @Test
    public void testMoodMeterHappy() {
        // Test when moodChecker is in the "Happy" range (6-10)
        adventure.moodChecker = 6;
        assertEquals("Happy", adventure.moodMeter());

        adventure.moodChecker = 10;
        assertEquals("Happy", adventure.moodMeter());
    }

    @Test
    public void testMoodMeterUnknown() {
        // Test when moodChecker is out of the defined range (< 0 or > 10)
        adventure.moodChecker = -1;
        assertEquals("Current mood is unknown...", adventure.moodMeter());

        adventure.moodChecker = 11;
        assertEquals("Current mood is unknown...", adventure.moodMeter());
    }
}
